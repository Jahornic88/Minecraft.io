# Hardware Prerequisites
- `200 Mb` memory for launcher
- `4 Gb` memory for Minecraft
- `60 Mb` storage for launcher
- `200` - `450 Mb` storage for Minecraft (1 version)
- `x64` architeture
- Atleast `Intel Celeron J4105` or `AMD FX-4100`
- Atleast `Intel HD Graphics 4000` or `AMD Radeon R5`