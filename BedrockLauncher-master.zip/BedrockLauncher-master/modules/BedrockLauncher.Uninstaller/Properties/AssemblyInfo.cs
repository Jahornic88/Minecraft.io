﻿using System.Resources;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Minecraft Bedrock Launcher Removal Tool")]
[assembly: AssemblyDescription("Removes the Launcher!")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CarJem Generations")]
[assembly: AssemblyProduct("Minecraft Bedrock Launcher Removal Tool")]
[assembly: AssemblyCopyright("Copyright ©  2021")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]


[assembly: Guid("3232778b-1a3b-4d31-88a1-7a43b8b66723")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: NeutralResourcesLanguage("en-US")]
