# Software Prerequisites
- Atleast Windows 10 `14393.0` or Windows 11 `22000.100`
- Account with administrative rights
- A Microsoft account with Minecraft for Windows 10 owned
- Minecraft for Windows 10 beta sign-up using non-legacy Xbobx Insider Hub