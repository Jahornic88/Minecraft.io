# Disclaimers
- This tool will not let you pirate **Minecraft for Windows 10**, as this launcher requires you to own a copy of it from the Microsoft Store
- This tool is in *early public beta*; hence there will be a lot of issues
- This tool is open source, and contributing is appreciated; however, redistributing the build is not recommended
- The screenshots shown may not represent the actual product due to early rapid prototyping