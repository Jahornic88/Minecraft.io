# Compiling
Make sure you meet the [developer software prerequisites](./DEV_SOFTWARE_PREREQUISITES.md) before you get started

1. Open the `.sln` project file in Visual Studio
2. Press the Build/Start Button