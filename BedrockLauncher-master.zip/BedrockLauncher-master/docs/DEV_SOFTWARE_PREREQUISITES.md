# Developer Software Prerequisites

## Softwares
- Visual Studio 2019
- Node.js
- PostSharp Community Edition

## Visual Studio Packages
- C++ Development Libraries
- `.NET` Framework Development Libraries