﻿using System.Collections.Generic;

namespace BedrockLauncher.Core.Classes.MediaWiki
{
    public class Limits
    {
        public int extracts { get; set; }
    }
}
