﻿using System.Collections.Generic;

namespace BedrockLauncher.Core.Classes.MediaWiki
{
    public class Continue
    {
        public string @continue { get; set; }
        public string cmcontinue { get; set; }
    }
}
