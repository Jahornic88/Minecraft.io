﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BedrockLauncher.Core.Classes.SkinPack
{
    public enum MCSkinGeometry
    {
        Normal,
        Custom,
        Slim
    }
}
